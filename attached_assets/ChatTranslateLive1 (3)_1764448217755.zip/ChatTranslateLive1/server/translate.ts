interface TranslationResult {
  translatedText: string;
  detectedLanguage: string;
  isTranslated: boolean;
}

const translationCache = new Map<string, TranslationResult>();

// Protected names that should not be translated
const PROTECTED_NAMES = ["Meme", "めめ"];
const PLACEHOLDER_PREFIX = "__PROTECTED_NAME_";

function replaceProtectedNames(text: string): { text: string; replacements: Map<string, string> } {
  const replacements = new Map<string, string>();
  let processedText = text;
  
  PROTECTED_NAMES.forEach((name, index) => {
    const placeholder = `${PLACEHOLDER_PREFIX}${index}__`;
    const regex = new RegExp(`\\b${name}\\b`, "gi");
    if (regex.test(processedText)) {
      processedText = processedText.replace(regex, placeholder);
      replacements.set(placeholder, name);
    }
  });
  
  return { text: processedText, replacements };
}

function restoreProtectedNames(text: string, replacements: Map<string, string>): string {
  let result = text;
  replacements.forEach((originalName, placeholder) => {
    result = result.replace(new RegExp(placeholder, "g"), originalName);
  });
  return result;
}

let lastRequestTime = 0;
const MIN_REQUEST_INTERVAL = 300;

async function rateLimitedFetch(url: string, options: RequestInit): Promise<Response> {
  const now = Date.now();
  const timeSinceLastRequest = now - lastRequestTime;

  if (timeSinceLastRequest < MIN_REQUEST_INTERVAL) {
    await new Promise((resolve) =>
      setTimeout(resolve, MIN_REQUEST_INTERVAL - timeSinceLastRequest)
    );
  }

  lastRequestTime = Date.now();
  return fetch(url, options);
}

export async function translateMessage(
  text: string,
  targetLanguage: string
): Promise<TranslationResult> {
  const cacheKey = `${text}:${targetLanguage}`;
  const cached = translationCache.get(cacheKey);
  if (cached) {
    console.log(`[CACHE HIT] "${text}"`);
    return cached;
  }

  if (text.length < 2 || /^[\s\W]+$/.test(text) || /^https?:\/\//.test(text)) {
    return {
      translatedText: text,
      detectedLanguage: "unknown",
      isTranslated: false,
    };
  }

  try {
    console.log(`[TRANSLATING] "${text}" to ${targetLanguage}`);

    // Protect names from translation
    const { text: processedText, replacements } = replaceProtectedNames(text);

    const response = await rateLimitedFetch("https://translate.googleapis.com/translate_a/single", {
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
      },
      body: new URLSearchParams({
        client: "gtx",
        sl: "auto",
        tl: targetLanguage,
        dt: "t",
        q: processedText,
      }).toString(),
    });

    if (!response.ok) {
      console.error(`[API ERROR] Status ${response.status}`);
      return {
        translatedText: text,
        detectedLanguage: "unknown",
        isTranslated: false,
      };
    }

    const result = await response.json();
    let translatedText = result[0]?.[0]?.[0] || text;
    const detectedLanguage = result[2] || "unknown";
    
    // Restore protected names
    translatedText = restoreProtectedNames(translatedText, replacements);
    
    // Determine if translation actually happened
    let isTranslated = false;
    const asianLanguages = ["ja", "ko", "zh", "th", "vi", "ar", "he"];
    
    // If the detected language is not the target language, translation happened
    if (detectedLanguage !== targetLanguage && detectedLanguage !== "unknown") {
      isTranslated = true;
    } else if (translatedText !== text && translatedText.length > 0) {
      // Or if output is different from input (case-sensitive for all)
      isTranslated = true;
    }

    const translation: TranslationResult = {
      translatedText,
      detectedLanguage,
      isTranslated,
    };

    translationCache.set(cacheKey, translation);
    console.log(`[TRANSLATED] "${text}" -> "${translatedText}" (${detectedLanguage}) isTranslated=${isTranslated}`);
    return translation;
  } catch (error) {
    console.error(`[TRANSLATION ERROR]`, error);
    return {
      translatedText: text,
      detectedLanguage: "unknown",
      isTranslated: false,
    };
  }
}

export function clearTranslationCache() {
  translationCache.clear();
}
