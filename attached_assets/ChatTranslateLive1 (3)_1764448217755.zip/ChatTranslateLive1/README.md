# Full Stack Application

Un repositorio listo para desplegar en Render.

## Tecnologías

- **Frontend**: React + TypeScript + Tailwind CSS + Shadcn UI
- **Backend**: Express.js + TypeScript
- **Database**: PostgreSQL (Neon)
- **Herramientas**: Vite, Drizzle ORM, TanStack Query

## Instalación

```bash
npm install
```

## Desarrollo

```bash
npm run dev
```

## Build para producción

```bash
npm run build
```

## Variables de Entorno

Crea un archivo `.env.local` en la raíz del proyecto. Puedes usar `.env.example` como referencia:

```bash
cp .env.example .env.local
```

**Variables requeridas:**

- `TWITCH_BOT_USERNAME` - El nombre de usuario del bot en Twitch
- `TWITCH_ACCESS_TOKEN` - Token OAuth del bot (obtener en https://twitchtokengenerator.com/)

**Cómo obtener credenciales de Twitch:**

1. Ve a https://twitchtokengenerator.com/
2. Selecciona los permisos necesarios para el bot
3. Autoriza la aplicación
4. Copia el token OAuth generado
5. Usa ese token como `TWITCH_ACCESS_TOKEN`

## Despliegue en Render

1. Conecta este repositorio a tu cuenta de Render
2. Render detectará automáticamente `render.yaml`
3. En el dashboard de Render, ve a **Environment** y agrega estas variables:
   - **Key:** `TWITCH_BOT_USERNAME` → **Value:** `tu_nombre_de_bot_aqui` (ej: `translatebot2024`)
   - **Key:** `TWITCH_ACCESS_TOKEN` → **Value:** `tu_token_oauth_aqui` (ej: `oauth:abcd1234...`)
4. Guarda los cambios
5. El deployment se hará automáticamente en cada push a main

**Nota:** Las credenciales de Twitch son secretas. Úsalas solo en tu cuenta de Render, nunca las commits al repositorio.

## Licencia

MIT
